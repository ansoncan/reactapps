import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PosterImage from '../Components/PosterImage';

const FilmDetail = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { film } = route.params;
  const [userType, setUserType] = useState<number | null>(null);

  useEffect(() => {
    const loadUserType = async () => {
      try {
        const userData = await AsyncStorage.getItem('user');
        console.log('📦 Raw user data from AsyncStorage:', userData);

        if (userData) {
          const parsed = JSON.parse(userData);
          console.log('👤 Parsed user object:', parsed);

          if (parsed && typeof parsed.type === 'number') {
            setUserType(parsed.type);
          } else {
            console.warn('⚠️ User object does not contain a valid type.');
          }
        } else {
          console.warn('⚠️ No user data found in AsyncStorage.');
        }
      } catch (error) {
        console.error('❌ Error reading user data from AsyncStorage:', error);
      }
    };

    loadUserType();
  }, []);

  const handleEditFilm = () => {
    navigation.navigate('AddFilmScreen' as never, { film } as never);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <PosterImage uri={film.poster} style={styles.poster} />
      <Text style={styles.title}>{film.title}</Text>

      <View style={styles.detailCard}>
        {[
          { label: 'Year', value: film.year },
          { label: 'Released', value: film.released },
          { label: 'Runtime', value: `${film.runtime} minutes` },
          { label: 'Language', value: film.language },
          { label: 'Genre', value: film.genre },
          { label: 'Director', value: film.director },
        ].map((item, index) => (
          <View key={index} style={styles.detailRow}>
            <Text style={styles.detailLabel}>{item.label}</Text>
            <Text style={styles.detailValue}>{item.value}</Text>
          </View>
        ))}
      </View>

      {userType === 1 && (
        <TouchableOpacity
          onPress={handleEditFilm}
          style={[styles.button, { backgroundColor: '#34C759' }]}
        >
          <Text style={styles.buttonText}>Add Film</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  poster: {
    width: '65%',
    aspectRatio: 2 / 3,
    borderRadius: 10,
    marginBottom: 20,
    backgroundColor: '#eee',
  },
  title: {
    fontSize: 26,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  detailCard: {
    width: '90%',
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  detailRow: {
    marginBottom: 10,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#444',
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 16,
    color: '#555',
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
  },
});

export default FilmDetail;
