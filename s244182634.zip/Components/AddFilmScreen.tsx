import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Platform,
  ScrollView,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { addFilm, Film } from '../service/film_api';
import PosterImage from '../Components/PosterImage';

interface RouteParams {
  film: Film;
}

type NavigationRoute = {
  key?: string;
  name?: string;
  path?: string;
  params: RouteParams;
};

const FilmDetail = () => {
  const { film } = useRoute<NavigationRoute>().params;
  const navigation = useNavigation();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkAdmin = async () => {
      try {
        const userData = await AsyncStorage.getItem('user');
        if (userData) {
          const parsed = JSON.parse(userData);
          console.log('User  Data:', parsed); // Log user data
          if (parsed.type === 1) {
            setIsAdmin(true);
          }
        }
      } catch (error) {
        console.error('Failed to check admin status:', error);
      }
    };

    checkAdmin();
  }, []);

  const handleAddFilmToDB = () => {
    Alert.alert('Confirm', 'Add this film to the database?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Add',
        onPress: async () => {
          try {
            await addFilm(film);
            Alert.alert('Success', 'Film added.');
          } catch (error) {
            const errMsg = (error as Error).message || 'An error occurred';
            Alert.alert('Error', errMsg);
          }
        },
      },
    ]);
  };

  const handleEditFilm = () => {
    navigation.navigate('AddFilmScreen' as never, { film } as never);
  };

  const handleNavigateToAddFilm = () => {
    navigation.navigate('AddFilmScreen' as never);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <PosterImage uri={film.poster} style={styles.poster} />
      <Text style={styles.title}>{film.title}</Text>

      <View style={styles.detailCard}>
        {[
          { label: 'Year', value: film.year },
          { label: 'Released', value: film.released },
          { label: 'Runtime', value: `${film.runtime} minutes` },
          { label: 'Language', value: film.language },
          { label: 'Genre', value: film.genre },
          { label: 'Director', value: film.director },
        ].map((item, index) => (
          <View key={index} style={styles.detailRow}>
            <Text style={styles.detailLabel}>{item.label}</Text>
            <Text style={styles.detailValue}>{item.value}</Text>
          </View>
        ))}
      </View>

      {isAdmin && (
        <>
          <TouchableOpacity onPress={handleAddFilmToDB} style={styles.button}>
            <Text style={styles.buttonText}>Add to Database</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleEditFilm} style={[styles.button, { marginTop: 10, backgroundColor: '#34C759' }]}>
            <Text style={styles.buttonText}>Edit Film</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleNavigateToAddFilm} style={[styles.button, { marginTop: 10, backgroundColor: '#007AFF' }]}>
            <Text style={styles.buttonText}>Go to Add Film Screen</Text>
          </TouchableOpacity>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  poster: {
    width: '65%',
    aspectRatio: 2 / 3,
    borderRadius: 10,
    marginBottom: 20,
    backgroundColor: '#eee',
  },
  title: {
    fontSize: 26,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  detailCard: {
    width: '90%',
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  detailRow: {
    marginBottom: 10,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#444',
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 16,
    color: '#555',
  },
  button: {
    backgroundColor: Platform.OS === 'ios' ? '#007AFF' : '#4DA8DA',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
  },
});

export default FilmDetail;
